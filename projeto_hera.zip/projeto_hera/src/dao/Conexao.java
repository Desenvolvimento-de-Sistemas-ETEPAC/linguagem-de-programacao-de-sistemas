package dao;
import java.sql.Connection;
import java.sql.DriverManager;
public class Conexao {	
		public static Connection conector() {
			java.sql.Connection conexao = null;
			String driver = "com.mysql.cj.jdbc.Driver";			
			//armazenando informa��es referente ao banco
			String url = "jdbc:mysql://localhost:3306/dbfic";
			String user = "root";
			String password = "123456";			
			//Estabelecendo a conex�o com o banco de dados
			try {
				Class.forName(driver);
				conexao = DriverManager.getConnection(url, user, password);
				return conexao;				
			} catch (Exception e) {
				// TODO: handle exception
				return null;
			}
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		conector();
	}
}
